# linebot
LineBot

สำหรับไฟล์ bot-checktoken.php, bot.php 
อ่านได้ตาม ลิงค์นี้นะครับ 
https://medium.com/@benz20003/chat-bot-%E0%B8%87%E0%B9%88%E0%B8%B2%E0%B8%A2%E0%B9%86-%E0%B8%94%E0%B9%89%E0%B8%A7%E0%B8%A2-line-messaging-api-php-nodejs-heroku-%E0%B9%81%E0%B8%9A%E0%B8%9A-step-by-step-943322819854

สำหรับไฟล์ bot-flex.php
อ่านได้ตาม ลิงค์นี้นะครับ
https://medium.com/@benz20003/%E0%B8%A1%E0%B8%B2%E0%B8%97%E0%B8%B3%E0%B9%83%E0%B8%AB%E0%B9%89-line-%E0%B8%A1%E0%B8%B5%E0%B8%A1%E0%B8%B2%E0%B8%81%E0%B8%81%E0%B8%A7%E0%B9%88%E0%B8%B2-message-%E0%B8%94%E0%B9%89%E0%B8%A7%E0%B8%A2-flex-message-%E0%B9%81%E0%B8%A5%E0%B8%B0-line-bot-designer-94ab0c3222a9?source=your_stories_page---------------------------
